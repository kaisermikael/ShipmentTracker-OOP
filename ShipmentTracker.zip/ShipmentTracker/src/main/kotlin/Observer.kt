interface Observer {
    fun update()
}