interface ShipmentUpdateStrategy {
    fun updateShipmentStatus(updateInfo: List<String>)
}