class Shipment(shipmentProps: List<String>): Subject {
    private val observers = mutableListOf<Observer>()
    var status: String
    var id: String
    var notes = mutableListOf<String>()
        private set
    var updateHistory = mutableListOf<ShippingUpdate>()
        private set
    var expectedDeliveryDate: Long
    var currentLocation: String

    override fun addObserver(observer: Observer) {
        observers.add(observer)
    }

    override fun removeObserver(observer: Observer) {
        observers.remove(observer)
    }

    override fun notifyObservers() {
        observers.forEach { it.update()}
    }

    init {
        // Defaults. Delivery date becomes -- if == 0, current location is Unknown before location update
        this.status = "created"
        this.id = shipmentProps[1]
        this.expectedDeliveryDate = 0
        this.currentLocation = "Unknown"
    }

    fun addNote(note: String) {
        notes.add(note)
        notifyObservers()
    }

    fun addUpdate(shippingUpdate: ShippingUpdate) {
        updateHistory.add(shippingUpdate)
        notifyObservers()
    }
}