class CanceledUpdateStrategy: ShipmentUpdateStrategy {
    override fun updateShipmentStatus(updateInfo: List<String>){
        val shipmentId = updateInfo[1]
        val currentShipment = TrackingSimulator.findShipment(shipmentId)
        if (currentShipment != null) {
            // No expected delivery, so becomes 0 and then -- in the ViewHelper
            currentShipment.expectedDeliveryDate = 0
            currentShipment.status = updateInfo[0]
        }
    }
}