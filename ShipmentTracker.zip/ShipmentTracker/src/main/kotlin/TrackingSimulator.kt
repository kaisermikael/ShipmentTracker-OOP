import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.InputStream
import java.lang.NullPointerException

object TrackingSimulator {
    private var shipments = ArrayList<Shipment>()

    fun findShipment(id: String): Shipment? {
        shipments.forEach {
            if (it.id.equals(id)) {
                return it
            }
        }
        return null
    }

    fun addShipment(shipment: Shipment) {
        shipments.add(shipment)
    }

    suspend fun runSimulation(fileName: String) = coroutineScope {
        val formattedStrings = parseTestFile(fileName)

        launch {
            println("Now starting simulation")
            formattedStrings.forEach {
                println("Current test line: $it")
                if (it[0] == "created") {
                    val newShipment = Shipment(it)
                    addShipment(newShipment)
                } else {
                    val currentShipment = findShipment(it[1])
                        ?: throw NullPointerException("This shipment does not exist. Cannot update nonexistent shipment.")
                    if (it[0] == "noteadded") {
                        // Adding notes only affects a Shipment's note list; not its update history or status
                        currentShipment.addNote(it[3])
                    } else {
                        val previousStatus = currentShipment.status
                        // Passes both the Shipment's current state and update info
                        val shippingUpdate = ShippingUpdate(previousStatus, it)
                        currentShipment.addUpdate(shippingUpdate)
                    }
                }
                delay(1000)
            }
        }
    }

    fun parseTestFile(fileName: String): MutableList<List<String>> {
        val inputStream: InputStream = File(fileName).inputStream()
        val lineList = mutableListOf<String>()
        inputStream.bufferedReader().useLines { lines -> lines.forEach { lineList.add(it)} }
        val formattedStrings = mutableListOf<List<String>>()
        lineList.forEach {
            val stringParts = it.split(",")
            formattedStrings.add(stringParts)
        }

        return formattedStrings
    }
}