import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import java.text.SimpleDateFormat

class TrackerViewHelper(shipmentId: String): Observer {
    val shipment = TrackingSimulator.findShipment(shipmentId)

    var shipmentId by mutableStateOf(shipment?.id ?: "")
        private set
    var shipmentNotes = mutableListOf<String>()
        private set
    var shipmentUpdateHistory = mutableListOf<ShippingUpdate>()
        private set
    var expectedShipmentDeliveryDate by mutableStateOf(shipment?.expectedDeliveryDate.toString())
        private set
    var shipmentStatus by mutableStateOf(shipment?.status ?: "Shipment not found")
        private set
    var shipmentLocation by mutableStateOf(shipment?.currentLocation ?: "NA")
        private set

    init{

        trackShipment(shipmentId)
    }

    override fun update() {
        this.shipmentNotes = shipment?.notes ?: mutableListOf()
        this.shipmentUpdateHistory = shipment?.updateHistory ?: mutableListOf()
        this.expectedShipmentDeliveryDate = shipment?.expectedDeliveryDate.toString()
        this.shipmentStatus = shipment?.status ?: ""
        this.shipmentLocation = shipment?.currentLocation ?: ""
    }

    fun trackShipment(id: String) {
        TrackingSimulator.findShipment(id)?.addObserver(this)
    }

    fun stopTracking(trackedShipments: SnapshotStateList<TrackerViewHelper>) {
        TrackingSimulator.findShipment(this.shipmentId)?.removeObserver(this)
        trackedShipments.remove(this)
    }
}