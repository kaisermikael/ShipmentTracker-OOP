// Copyright 2000-2021 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import kotlinx.coroutines.launch

@Composable
fun ShipmentTrackingView(viewHelper: TrackerViewHelper, trackedShipments: SnapshotStateList<TrackerViewHelper>) {
    Column (modifier = Modifier
        .background(color = Color.LightGray)
        .padding(10.dp)
    ) {
        if (viewHelper.shipment == null) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("There is no Shipment with that ID", fontSize = 25.sp)
                IconButton(onClick = {
                    viewHelper.stopTracking(trackedShipments)
                }) {
                    Icon(Icons.Filled.Close, "Stop Tracking Shipment")
                }
            }
        } else {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Tracking Shipment: ${viewHelper.shipmentId}", fontSize = 25.sp)
                IconButton(onClick = {
                    viewHelper.stopTracking(trackedShipments)
                }) {
                    Icon(Icons.Filled.Close, "Stop Tracking Shipment")
                }
            }
            Row {
                Column {
                    Text("Status: ${viewHelper.shipmentStatus}")
                    Text("Location: ${viewHelper.shipmentLocation}")
                    if (viewHelper.expectedShipmentDeliveryDate == "0") {
                        Text("Expected Delivery Date: --")
                    } else {
                        Text("Expected Delivery Date: ${viewHelper.expectedShipmentDeliveryDate}")
                    }
                    Text("")
                }
            }
            Row {
                Column {
                    Text("Status Updates:")
                    Column {
                        for (shippingUpdate in viewHelper.shipmentUpdateHistory) {
                            // Doesn't update status for new location, as according to Joseph's video
                            if (shippingUpdate.newStatus == "location") {
                                continue
                            }

                            Text("Shipment went from ${shippingUpdate.previousStatus} to ${shippingUpdate.newStatus} at ${shippingUpdate.timestamp}")
                        }
                    }
                    Text("")
                }
            }
            Row {
                Column {
                    Text("Notes:")
                    for (note in viewHelper.shipmentNotes) {
                        Text(note)
                    }
                    Text("")
                }
            }
        }
    }
}

@Composable
@Preview
fun App() {

    val coroutineScope = rememberCoroutineScope()
    coroutineScope.launch {
        TrackingSimulator.runSimulation("test.txt")
    }

    MaterialTheme {
        var idInput by remember { mutableStateOf("")}
        val trackedShipments = remember { mutableStateListOf<TrackerViewHelper>()}

        Column {
            Row {
                TextField(idInput, onValueChange = { idInput = it })
                Button(
                    onClick = {
                        println("Now trying to track shipment: " + idInput)
                        trackedShipments.add(TrackerViewHelper(idInput))
                    },
                ) {
                    Text("Track Shipment")
                }
            }
            LazyColumn (verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(10.dp)) {
                items(trackedShipments) { trackedShipment ->
                    ShipmentTrackingView(trackedShipment, trackedShipments)
                }
            }
        }
    }
}

fun main() = application {
    Window(onCloseRequest = ::exitApplication) {
        App()
    }
}
