class DelayedUpdateStrategy: ShipmentUpdateStrategy {
    override fun updateShipmentStatus(updateInfo: List<String>){
        val shipmentId = updateInfo[1]
        val currentShipment = TrackingSimulator.findShipment(shipmentId)
        if (currentShipment != null) {
            currentShipment.expectedDeliveryDate = updateInfo[3].toLong()
            currentShipment.status = updateInfo[0]
        }
    }
}