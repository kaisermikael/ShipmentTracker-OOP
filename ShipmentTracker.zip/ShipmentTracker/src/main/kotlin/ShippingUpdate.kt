class ShippingUpdate(previousStatus: String, updateProps: List<String>) {
    var previousStatus: String
    var newStatus: String
    var timestamp: Long

    init {
        this.previousStatus = previousStatus
        this.newStatus = updateProps[0]
        this.timestamp = updateProps[2].toLong()
        performShipmentStrategy(updateProps)
    }

    private fun performShipmentStrategy(updateProps: List<String>) {
        // Utilizes structure of: updateType, shipmentId, timestampOfUpdate,... other info
        val shipmentUpdateStrategies = mapOf<String, ShipmentUpdateStrategy>(
            Pair("shipped", ShippedUpdateStrategy()),
            Pair("location", LocationUpdateStrategy()),
            Pair("delivered", DeliveredUpdateStrategy()),
            Pair("delayed", DelayedUpdateStrategy()),
            Pair("lost", LostUpdateStrategy()),
            Pair("canceled", CanceledUpdateStrategy()),
        )

        shipmentUpdateStrategies[updateProps[0]]?.updateShipmentStatus(updateProps)
    }
}