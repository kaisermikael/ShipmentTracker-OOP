class DeliveredUpdateStrategy: ShipmentUpdateStrategy {
    override fun updateShipmentStatus(updateInfo: List<String>){
        val shipmentId = updateInfo[1]
        val currentShipment = TrackingSimulator.findShipment(shipmentId)
        if (currentShipment != null) {
            // The "expected" delivery date is... right now. Because it was just delivered.
            currentShipment.expectedDeliveryDate = updateInfo[2].toLong()
            currentShipment.status = updateInfo[0]
        }
    }
}