import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class ShipmentTest {

    @Test
    fun getAndSetStatus() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)

        assertEquals("created", testShipment.status)

        testShipment.status = "testStatus"
        assertEquals("testStatus", testShipment.status)
    }

    @Test
    fun getAndSetId() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)

        assertEquals("testId", testShipment.id)

        testShipment.id = "newTestId"
        assertEquals("newTestId", testShipment.id)
    }

    @Test
    fun getAndAddNotes() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)
        val emptyTestList = listOf<String>()

        assertEquals(emptyTestList, testShipment.notes)

        testShipment.addNote("This is a Test Note")
        assertEquals("This is a Test Note", testShipment.notes[0])
        testShipment.addNote("This is another Test Note")
        assertNotEquals("This is a Test Note", testShipment.notes[1])
        assertEquals("This is another Test Note", testShipment.notes[1])

    }

    @Test
    fun getAndAddUpdateHistory() {
        val testShipmentProps = listOf("canceled", "testId")
        val testShipment = Shipment(testShipmentProps)
        val emptyTestList = listOf<ShippingUpdate>()
        val testShippingUpdatePropsList = listOf("delivered", "testId", "12341234")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals(emptyTestList, testShipment.updateHistory)

        testShipment.addUpdate(testShippingUpdate)
        assertEquals("created", testShipment.updateHistory[0].previousStatus)
        assertEquals("delivered", testShipment.updateHistory[0].newStatus)
        assertEquals(12341234, testShipment.updateHistory[0].timestamp)
    }

    @Test
    fun getAndSetExpectedDeliveryDate() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)

        assertEquals(0, testShipment.expectedDeliveryDate)

        testShipment.expectedDeliveryDate = 12341234
        assertEquals(12341234, testShipment.expectedDeliveryDate)
    }

    @Test
    fun getAndSetCurrentLocation() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)

        assertEquals("Unknown", testShipment.currentLocation)

        testShipment.currentLocation = "testLocation"
        assertEquals("testLocation", testShipment.currentLocation)
    }

    @Test
    fun observerTests() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)
        val testViewHelper = TrackerViewHelper("testId")

        testShipment.addObserver(testViewHelper)
        // If not exception is thrown, then the observer was successfully
        // added and then removed
        testShipment.removeObserver(testViewHelper)
        testShipment.notifyObservers()
    }
}