import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class TrackerViewHelperTest {

    @Test
    fun getShipmentId() {
        val testShipmentProps = listOf("canceled", "testId")
        val testShipment2 = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment2)
        val testTrackerViewHelper2 = TrackerViewHelper("testId")

        assertEquals(testShipment2.id, testTrackerViewHelper2.shipmentId)
    }

    @Test
    fun getShipmentNotes() {
        val testShipmentProps = listOf("canceled", "testId")
        val testShipment3 = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment3)
        val testTrackerViewHelper3 = TrackerViewHelper("testId")

        assertEquals(testShipment3.notes, testTrackerViewHelper3.shipmentNotes)
    }

    @Test
    fun getShipmentUpdateHistory() {
        val testShipmentProps = listOf("canceled", "testId")
        val testShipment = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment)
        val testTrackerViewHelper = TrackerViewHelper("testId")

        assertEquals(testShipment.updateHistory, testTrackerViewHelper.shipmentUpdateHistory)
    }
}