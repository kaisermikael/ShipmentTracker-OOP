import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class TrackingSimulatorTest {

    @Test
    fun findAndAddShipments() {
        val testShipmentProps1 = listOf("canceled", "testId1")
        val testShipment1 = Shipment(testShipmentProps1)
        val testShipmentProps2 = listOf("delivered", "testId2")
        val testShipment2 = Shipment(testShipmentProps2)
        val testShipmentProps3 = listOf("canceled", "testId3")
        val testShipment3 = Shipment(testShipmentProps3)

        TrackingSimulator.addShipment(testShipment1)
        TrackingSimulator.addShipment(testShipment2)
        TrackingSimulator.addShipment(testShipment3)

        // If each of these findShipment calls work and the
        // tests pass, then addShipment also has worked successfully
        assertEquals(testShipment1, TrackingSimulator.findShipment("testId1"))
        assertEquals(testShipment2, TrackingSimulator.findShipment("testId2"))
        assertEquals(testShipment3, TrackingSimulator.findShipment("testId3"))
    }

    @Test
    suspend fun runSimulation() {
        val testFormattedStrings = TrackingSimulator.parseTestFile("test.txt")
        val testList1 = listOf("created", "s10000", "1652712855468")
        val testList2 = listOf("delivered", "s10009", "1652712855468")
        val testShipmentProps = listOf("created", "testId", "12341234")
        val testShipment = Shipment(testShipmentProps)

        assertEquals(testList1, testFormattedStrings[0])
        assertEquals(testList2, testFormattedStrings[80])

        TrackingSimulator.runSimulation("test2.txt")
        assertEquals(testShipment, TrackingSimulator.findShipment("testId"))
    }
}