import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class ShippingUpdateTest {

    @Test
    fun getAndSetPreviousStatus() {
        val testShippingUpdatePropsList = listOf("delivered", "testId", "12341234")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals("created", testShippingUpdate.previousStatus)

        testShippingUpdate.previousStatus = "testPreviousStatus"
        assertEquals("testPreviousStatus", testShippingUpdate.previousStatus)
    }

    @Test
    fun getAndSetNewStatus() {
        val testShippingUpdatePropsList = listOf("delivered", "testId", "12341234")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals("delivered", testShippingUpdate.newStatus)

        testShippingUpdate.newStatus = "testNewStatus"
        assertEquals("testNewStatus", testShippingUpdate.newStatus)
    }

    @Test
    fun getAndSetTimestamp() {
        val testShippingUpdatePropsList = listOf("delivered", "testId", "12341234")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals(12341234, testShippingUpdate.timestamp)

        testShippingUpdate.timestamp = 56785678
        assertEquals(56785678, testShippingUpdate.timestamp)
    }

    @Test
    fun CanceledUpdateStrategy() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment)
        val testShippingUpdatePropsList = listOf("canceled", "testId", "12341234")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals("canceled", testShippingUpdate.newStatus)
        assertEquals("created", testShippingUpdate.previousStatus)
        assertEquals(12341234, testShippingUpdate.timestamp)
    }

    @Test
    fun DelayedUpdateStrategy() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment)
        val testShippingUpdatePropsList = listOf("delayed", "testId", "12341234", "56785678")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals("delayed", testShippingUpdate.newStatus)
        assertEquals("created", testShippingUpdate.previousStatus)
        assertEquals(12341234, testShippingUpdate.timestamp)
    }

    @Test
    fun DeliveredUpdateStrategy() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment)
        val testShippingUpdatePropsList = listOf("delivered", "testId", "12341234")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals("delivered", testShippingUpdate.newStatus)
        assertEquals("created", testShippingUpdate.previousStatus)
        assertEquals(12341234, testShippingUpdate.timestamp)
    }

    @Test
    fun LocationUpdateStrategy() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment)
        val testShippingUpdatePropsList = listOf("location", "testId", "12341234", "testLocation")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals("location", testShippingUpdate.newStatus)
        assertEquals("created", testShippingUpdate.previousStatus)
        assertEquals(12341234, testShippingUpdate.timestamp)
    }

    @Test
    fun LostUpdateStrategy() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment)
        val testShippingUpdatePropsList = listOf("lost", "testId", "12341234")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals("lost", testShippingUpdate.newStatus)
        assertEquals("created", testShippingUpdate.previousStatus)
        assertEquals(12341234, testShippingUpdate.timestamp)
    }

    @Test
    fun ShippedUpdateStrategy() {
        val testShipmentProps = listOf("", "testId")
        val testShipment = Shipment(testShipmentProps)
        TrackingSimulator.addShipment(testShipment)
        val testShippingUpdatePropsList = listOf("shipped", "testId", "12341234", "56785678")
        val testShippingUpdate = ShippingUpdate("created", testShippingUpdatePropsList)

        assertEquals("shipped", testShippingUpdate.newStatus)
        assertEquals("created", testShippingUpdate.previousStatus)
        assertEquals(12341234, testShippingUpdate.timestamp)
    }
}